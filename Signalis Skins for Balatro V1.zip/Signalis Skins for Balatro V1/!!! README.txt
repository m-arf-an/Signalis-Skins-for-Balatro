### INSTALLATION

Requires 7-Zip, afaik WinRAR will not work

1) Navigate to your installation of Balatro
	(for steam, right click the game in your library list, go to Manage > Browse local files)

2) Open Balatro.exe with 7-Zip as if it were a .zip

3) Drag the "resources" folder into the 7-Zip folder



### PLEASE FOLLOW ORIGINAL ARTISTS

spades face cards by twt@64suns
pack & resprites by twt@m_arf_an



### Notes
-if you already have a skin pack that replaces the Default poker card skins, this will delete your old pack.
-if you wish to use parts of both skin packs, you'll have to edit the 2x/8BitDeck.png texture yourself
-i probably won't update this pack
-Sesbian Lex